
package DbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import stockmanagement.AddStock;

public class Dbconnection {
     static Connection conn=null;
    public static Connection ConnectDB()throws Exception{
        try{
      // Class.forName("com.mysql.cj.JDBC");
      conn=DriverManager.getConnection("jdbc:mysql://localhost/stock","root","");
      AddStock.dbtestlbl.setText("Connected to localhost");
       JOptionPane.showMessageDialog(null,"Connected to localhost");
        return conn;
        }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
        JOptionPane.showMessageDialog(null,"Not Connected to localhost");
        AddStock.dbtestlbl.setText("Not Connected to localhost");
        return null;
    }
}
