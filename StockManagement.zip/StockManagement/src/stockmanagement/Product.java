
package stockmanagement;

public class Product {
    private static byte[] image;
    private static int id;
    private static String date;
    private static String name;
    private static String ptype;
    private static double bp;
    private static double sp;
    private static double prft;
    public Product(byte[] image,int id,String date,String name,String ptype,double bp,double sp,double prft){
       this.image=image;
       this.id=id;
       this.date=date;
       this.name=name;
       this.bp=bp;
       this.sp=sp;
       this.prft=sp-bp;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPtype() {
        return ptype;
    }

    public void setPtype(String ptype) {
        this.ptype = ptype;
    }

    public double getBp() {
        return bp;
    }

    public void setBp(double bp) {
        this.bp = bp;
    }

    public double getSp() {
        return sp;
    }

    public void setSp(double sp) {
        this.sp = sp;
    }

    public double getPrft() {
        return prft;
    }

    public void setPrft(double prft) {
        this.prft = prft;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
}
