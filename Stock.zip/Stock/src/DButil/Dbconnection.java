
package DButil;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class Dbconnection {
    static Connection conn=null;
    public static Connection getConnection()throws Exception{
    try{
     conn=DriverManager.getConnection("jdbc:mysql://localhost/stock","root","");
     //JOptionPane.showMessageDialog(null, "Connected to localhost", "System Info", JOptionPane.INFORMATION_MESSAGE);
     return conn;
    }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex, "System Info", JOptionPane.INFORMATION_MESSAGE);
         return null; 
    } 
    }
}
