
package AnimatedImage;

public class SplashImage extends javax.swing.JFrame {

    public SplashImage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblimage1 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel3 = new javax.swing.JLabel();
        lblimage2 = new javax.swing.JLabel();
        lblimage3 = new javax.swing.JLabel();
        lblimage4 = new javax.swing.JLabel();
        lblimage5 = new javax.swing.JLabel();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Animations.............");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, 240, -1));

        lblimage1.setBackground(new java.awt.Color(0, 0, 255));
        lblimage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Circles-3.gif"))); // NOI18N
        jPanel1.add(lblimage1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 650));

        jProgressBar1.setBackground(new java.awt.Color(255, 255, 255));
        jProgressBar1.setForeground(new java.awt.Color(0, 51, 204));
        jPanel1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 371, 450, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("        KimsCorder");
        jLabel3.setAlignmentX(2.0F);
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 430, 90));

        lblimage2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/promise-day-latest-gif-image-download.gif"))); // NOI18N
        jPanel1.add(lblimage2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        lblimage3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cherry.jpg"))); // NOI18N
        lblimage3.setText("jLabel2");
        jPanel1.add(lblimage3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-5, 0, 510, 550));

        lblimage4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/600px-Morphing_3D_graph.gif"))); // NOI18N
        jPanel1.add(lblimage4, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 4, 500, 550));

        lblimage5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Circles-3.gif"))); // NOI18N
        lblimage5.setText("jLabel5");
        jPanel1.add(lblimage5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SplashImage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JProgressBar jProgressBar1;
    public static javax.swing.JLabel lblimage1;
    public static javax.swing.JLabel lblimage2;
    public static javax.swing.JLabel lblimage3;
    public static javax.swing.JLabel lblimage4;
    public static javax.swing.JLabel lblimage5;
    // End of variables declaration//GEN-END:variables

}
