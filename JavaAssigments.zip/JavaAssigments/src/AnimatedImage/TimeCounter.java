package AnimatedImage;

import java.sql.SQLException;
import javax.swing.JOptionPane;

public class TimeCounter {
    private static SplashImage scimg;
    public static void  Annimation(){
       
        try{
      for(int i=100;i<=100;i--){
          Thread.sleep(400);
          scimg.jLabel1.setText(i+"s");
          scimg.jProgressBar1.setValue(i);
          if(i==20){
             scimg.lblimage2.setVisible(false);
             scimg.lblimage1.setVisible(true);
             scimg.lblimage3.setVisible(false);
             scimg.lblimage4.setVisible(false);
             scimg.lblimage5.setVisible(false);
          }else if(i==40){
             scimg.lblimage2.setVisible(true);
             scimg.lblimage1.setVisible(false);
             scimg.lblimage3.setVisible(false);
             scimg.lblimage4.setVisible(false);
             scimg.lblimage5.setVisible(false);
          }else if(i==60){
             scimg.lblimage2.setVisible(false);
             scimg.lblimage1.setVisible(false);
             scimg.lblimage3.setVisible(true);
             scimg.lblimage4.setVisible(false);
             scimg.lblimage5.setVisible(false);
          }else if(i==80){
             scimg.lblimage2.setVisible(false);
             scimg.lblimage1.setVisible(false);
             scimg.lblimage3.setVisible(false);
             scimg.lblimage4.setVisible(true);
             scimg.lblimage5.setVisible(false);
          }else if(i==100){
             scimg.lblimage2.setVisible(false);
             scimg.lblimage1.setVisible(false);
             scimg.lblimage3.setVisible(false);
             scimg.lblimage4.setVisible(false);
             scimg.lblimage5.setVisible(true);
          }else if(i==0){
              //scimg.dispose();
              JOptionPane.showMessageDialog(null, "Animation time expired");
              Annimation();
          }
      }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    }
    public static void main(String[] args) throws SQLException{
   scimg=new SplashImage();
 scimg.setLocationRelativeTo(null);
  scimg.setVisible(true);
    Annimation();
    }
}
