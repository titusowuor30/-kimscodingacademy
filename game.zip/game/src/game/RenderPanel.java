
package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class RenderPanel extends JPanel{
//public static int incColor=0;
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        g.setColor(new Color(999));
        g.fillRect(0, 0, 805, 600);
        Snake snake=Snake.snake;
        for(Point point:snake.snakepoints){
            g.setColor(Color.ORANGE);
            g.fillRect(point.x*snake.scale, point.y*snake.scale, snake.scale, snake.scale);
        }
         g.fillRect(snake.head.x*snake.scale, snake.head.y*snake.scale, snake.scale, snake.scale);
          g.setColor(Color.red);
         g.fillRect(snake.cherry.x*snake.scale, snake.cherry.y*snake.scale, snake.scale, snake.scale);
    }
 
}
