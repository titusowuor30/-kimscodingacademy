package game;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Snake implements ActionListener,KeyListener{
public JFrame frame;
public boolean over=false,paused;
public  Dimension dim;
public RenderPanel panel;
public Timer timer=new Timer(5,this);
public static Snake snake;
public static final int up=0,down=1,left=2,right=3,scale=10;
public ArrayList<Point>snakepoints=new ArrayList<Point>();
public int ticks=0,direction=down,score,tailLength;
public Random random;
public Point head,cherry;
    public Snake() {
       dim=Toolkit.getDefaultToolkit().getScreenSize();
        frame=new JFrame("snake");
        frame.setVisible(true);
        frame.setSize(800,600);
        panel=new RenderPanel();
        frame.add(panel);
        frame.addKeyListener(this);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       StartGame();
    }
    public void StartGame(){
        over=false;
        score=0;
        tailLength=1;
        direction=down;
        paused=false;
      head=new Point(0,-1);
        random=new Random();
        snakepoints.clear();
        cherry=new Point(random.nextInt(66),random.nextInt(79) );
        for(int i=0;i<tailLength;i++){
        snakepoints.add(new Point(head.x,head.y));
        }
        timer.start();   
    }
  public static void main(String[] args){
       snake=new Snake();
  }  

    @Override
    public void actionPerformed(ActionEvent e) {
      panel.repaint();
      ticks++;
      if(ticks % 10==0 && head !=null && over !=true && !paused){   
      snakepoints.add(new Point(head.x,head.y));
      if(snakepoints.size()>tailLength)
        snakepoints.remove(0);
      if(direction==up)
          if(head.y-1>0 && noTailAt(head.x,head.y-1))
     head=new Point(head.x,head.y-1);
      else
          over=true;
    
      if(direction==down)
          if(head.y+1<67 && noTailAt(head.x,head.y+1))
      head=new Point(head.x,head.y+1);
     else
          over=true;
     
      if(direction==left)
          if(head.x-1>0 && noTailAt(head.x-1,head.y))
     head=new Point(head.x-1,head.y);
     else
          over=true;
      if(direction==right)
           if(head.x+1<80 && noTailAt(head.x+1,head.y))
      head=new Point(head.x+1,head.y);
      else
       over=true;
    
        if(cherry !=null){
          if(head.equals(cherry)){
              score+=10;
              tailLength++;
              cherry.setLocation(random.nextInt(66),random.nextInt(79));
          }
      }
    }
}

    @Override
    public void keyTyped(KeyEvent e) {
      
    }

    @Override
    public void keyPressed(KeyEvent e) {
      if(e.getKeyCode()==KeyEvent.VK_UP && direction !=down)
          direction=up; 
      if(e.getKeyCode()==KeyEvent.VK_DOWN && direction !=up)
           direction=down;
      if(e.getKeyCode()==KeyEvent.VK_LEFT && direction !=right)
           direction=left; 
      if(e.getKeyCode()==KeyEvent.VK_RIGHT && direction !=left)
           direction=right;
      if(e.getKeyCode()==KeyEvent.VK_N){
          if(over)
            StartGame();   
          else
           paused=!paused;   
         
      }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }

    private boolean noTailAt(int x, int y) {
        for(Point point:snakepoints){
        if(point.equals(head))
            //JOptionPane.showMessageDialog(null,"collided");
            return true;
        }
    return false;
        
      }
}    
