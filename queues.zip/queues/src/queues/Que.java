
package queues;

public class Que {
 private int[] q;
 private int size;
 private int total;
 private int front;
 private int rear;
 public Que(){
     q=new int[50];
     size=50;
     total=0;
     front=0;
     rear=0;
 }
 public Que(int size){
     this.size=size;
     q=new int[this.size];
      size=50;
     total=0;
     front=0;
     rear=0;
 }
 public boolean enque(int item){
    if(isFull()){
        return false;
    } else{
        total++;
        q[rear]=item;
        rear=(rear+1)%size;
        return true;
    }
 }
 public int deque(){
     int item=q[front];
     total--;
     front=(front+1)%size;
     return item;
 }
 public boolean isFull(){
     if(size==total){
         return true;
     }else{
         return false;
     }
 }
 public void ShowAll(){
     int f=front;
     if(total!=0){
         for(int i=0;i<total;i++){
         System.out.println(" "+q[f]);
         f=(f+1)%size;
     }
     }
 }
}
