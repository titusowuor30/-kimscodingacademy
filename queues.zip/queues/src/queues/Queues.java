
package queues;

public class Queues {

   
    public static void main(String[] args) {
//        Que q=new Que();
//        q.enque(3);
//        q.enque(6);
//         q.enque(67);
//          q.enque(62);
//         q.ShowAll();
Personq q=new Personq();
q.enque(new Person("Roni","3456"));
q.enque(new Person("Emmy","34fy6"));
  
  q.ShowAll();
    }
    
}
