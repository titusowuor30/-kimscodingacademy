
package linkedlist;
import java.util.Scanner;
public class MainList {
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
  LinkedList l=new  LinkedList();
//  System.out.println("Enter list values(-1 to save input)\n");
//  int value=in.nextInt();
  l.insertAtFirst(43);
  l.insertAtFirst(56);
  l.insertAtFirst(65);
  l.deleteItem(42);
  System.out.println("new list values after deletion\n");
  l.PrintList();
    }
}
