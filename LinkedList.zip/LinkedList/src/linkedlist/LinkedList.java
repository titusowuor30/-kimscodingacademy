
package linkedlist;

public class LinkedList {
 private Node head;
 public LinkedList(){
    head=new Node();
    head.value=0;
    head.link=null;
 }
 public boolean insertAtFirst(int item){
    while(item !=-1){
     Node n=new Node();
     n.value=item;
     n.link=head;
     head=n;
     return true;
    }
     return false;
 }
 class Node{
        public Node link;
        private int value;
    }
 public void PrintList(){
     Node zip=head.link;
     while(zip !=null){
      System.out.println("\t"+zip.value+"\t");
      zip=zip.link;
     }
 }
public boolean deleteItem(int item){
    if(head.link.value==item){
        head=head.link.link;
        return true;
    }else{
        Node x=head;
        Node y=head.link;
        while(true){
           if(y==null||y.value==item){
               break;
           }else{
               x=y;
               y=y.link;
           }
            
        }
        if(y !=null){
            x.link=y.link;
            return true;
        }else{
            return false;
        }
    }
}    
}
