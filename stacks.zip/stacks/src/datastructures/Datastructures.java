
package datastructures;
import java.util.*;
public class Datastructures {

    public static void main(String[] args) {
//     Scanner in=new Scanner(System.in);
//     Stack stack=new Stack();
//    // System.out.println("Enter stack values");
//     if(!stack.isFull()){
//        //int value=in.nextInt();
//        stack.push(7);
//         stack.push(5);
//         stack.push(3);
//        //if(value==-1){
//           
//       // }
//     }
//      System.out.println(stack.pop());
//      System.out.println(stack.pop());
//      System.out.println(stack.pop());
//      
Person p1=new Person("Roni","3456");
Person p2=new Person("Emmy","34fy6");
PersonStack stack=new PersonStack();
if(!stack.isFull()){
stack.push(p1);
stack.push(p2);
}
System.out.println(stack.pop().toString());
System.out.println(stack.pop().toString());
    }
    
} 
