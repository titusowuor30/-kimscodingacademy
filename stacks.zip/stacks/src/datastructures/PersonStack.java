
package datastructures;
public class PersonStack {
   private int top;
   private int size;
   private Person[] stack;
   public PersonStack(){
       top=-1;
       size=50;
       stack=new Person[50];
   }
    public PersonStack(int size){
       top=-1;
       this.size=size;
       stack=new Person[this.size];
   }
    public boolean push(Person person){
    if(!isFull()){
        top++;
        stack[top]=person;
        return true;
    }else{
       return false;
    }
}
    public Person pop(){
        try{
         return (stack[top--]);
        }catch(Exception ex){
            System.out.println("nothing to display");
            return null;
        }
        }
    public boolean isEmpty(){
          try{
        return (top==-1); 
        }catch(Exception ex){
            System.out.println("empty stack");
            return false;
        }
    }
    public boolean isFull(){
        try{
        return (top==stack.length-1);
        }catch(Exception ex){
            System.out.println("stack is full");
            return false;
        }
    }
}
