
package datastructures;

public class Stack {
 private int[] stack;
 private int size;
 private int top;
 public Stack(){
     top=-1;
     size=50;
     stack=new int[50];
 }
 public Stack(int size){
      top=-1;
    this.size=size;
     stack=new int[this.size];
 }
 public boolean push(int item){
     if(!isFull()){
     top++;
     stack[top]=item;
     return true;
     }else{
     return false;
     }
 }
 public int pop(){
      try{
       return stack[top--];
     }catch(Exception ex){
         System.out.println("no value to print,,,end of stack");
           return 0; 
     }
   
 }
 public boolean isEmpty(){
     try{
      return (top==-1);
     }catch(Exception ex){
         System.out.println("stack is empty");
         return false;
     }
    
 }
 public boolean isFull(){
     try{
     return(top==stack.length-1);
     }catch(Exception ex){
         System.out.println("stack is full");
         return false;
     }
     
     
 }
}
